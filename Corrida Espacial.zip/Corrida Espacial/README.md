# Space Sweeper
![Screenshot](http://lavaleakgames.com/gamejam/2014/fatecscs/Space-Sweeper_splash-screen.jpg)  
  
A accidental game about physics.  
My first Unity game made in a game jam in my college, Faculdade de Tecnologia de São Caetano do Sul (Fatec SCS) in 2014.

Music by: [Lucas Sabião](https://github.com/lsabiao)
