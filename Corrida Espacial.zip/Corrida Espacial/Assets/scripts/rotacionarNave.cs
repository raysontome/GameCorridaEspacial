﻿using UnityEngine;
using System.Collections;

public class rotateCar : MonoBehaviour {
	
	void FixedUpdate () {
		float h = Input.GetAxis("Rotacionar Nave");
		this.transform.Rotate (new Vector3(0,0,-h));
		if(Input.GetKey(KeyCode.A)){
			this.transform.Rotate (new Vector3(0,0,1f));
		}
		if(Input.GetKey(KeyCode.D)){
			this.transform.Rotate (new Vector3(0,0,-1f));
		}
	}
}
