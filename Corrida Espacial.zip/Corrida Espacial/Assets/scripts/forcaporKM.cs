﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class KmUI : MonoBehaviour {

	public GameObject car;
	Text text;

	void Awake () {
		text = GetComponent<Text>();
	}

	void Update () {
		text.text="Acel.: "+car.GetComponent<addForce>().acceleration;
	}
}
