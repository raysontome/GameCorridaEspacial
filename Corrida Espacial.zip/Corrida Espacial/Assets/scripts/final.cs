﻿using UnityEngine;
using System.Collections;

public class final : MonoBehaviour {

	public GameObject camStop;
	public Transform newTarget;

	void OnTriggerEnter2D(Collider2D other){
		if(other.tag=="Player"){
			camStop.GetComponent<camYmove>().target=newTarget;
		}
	}
}
