﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class fallCount : MonoBehaviour {
	
	public int falls = 0;
	Text text;
	
	void Awake () {
		text = GetComponent<Text>();
	}
	
	void Update () {
		text.text="Quedas: "+falls;
	}
}