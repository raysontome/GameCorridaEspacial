﻿using UnityEngine;
using System.Collections;

public class quiting : MonoBehaviour {
	
	void Update () {
		if (Input.GetKey(KeyCode.Escape)){
			Application.Quit();
		}
	}
}
