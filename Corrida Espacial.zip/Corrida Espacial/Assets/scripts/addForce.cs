﻿using UnityEngine;
using System.Collections;

public class addForce : MonoBehaviour {
	
	public float acceleration;
	[SerializeField]
	private bool correctedMass;
	public Vector2 CenterOfMass;

	private void CorrectMass(){
		this.GetComponent<Rigidbody2D>().centerOfMass = CenterOfMass;
		correctedMass = true;
	}

	void Start () {

	}
	
	void FixedUpdate () {
		if(!correctedMass){CorrectMass();}
		if(Input.GetButton("Acelerador")&&acceleration<200f||Input.GetKey(KeyCode.LeftControl)&&acceleration<200f){
			acceleration=acceleration+1f;
		}
		else if(Input.GetButton("Acelerador")&&acceleration==200f||Input.GetKey(KeyCode.LeftControl)&&acceleration==200f){
			acceleration=200f;
		}
		else if (acceleration>0f){
			acceleration--;
		}
		this.GetComponent<Rigidbody2D>().AddForce(new Vector2(0.1f*acceleration,0f),ForceMode2D.Force);
	}
}
