﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class nutsCount : MonoBehaviour {

	public int nuts = 0;
	Text text;
	
	void Awake () {
		text = GetComponent<Text>();
	}

	void Update () {
		text.text="Roscas: "+nuts;
	}
}
