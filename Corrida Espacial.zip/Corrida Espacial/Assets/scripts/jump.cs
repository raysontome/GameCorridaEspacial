﻿using UnityEngine;
using System.Collections;

public class jump : MonoBehaviour {

	public GameObject carAll;
	public bool letJump;

	void OnCollisionEnter2D(Collision2D other){
		if (other.collider.tag=="Ground"){
			letJump = true;
		}
	}

	void Start () {
	}

	void FixedUpdate () {
		if (Input.GetButtonDown("Pulo")||Input.GetKey(KeyCode.Space)){
			if (letJump){
				carAll.transform.Translate(0f,1f,0f);
				letJump=false;
			}
		}
	}
}