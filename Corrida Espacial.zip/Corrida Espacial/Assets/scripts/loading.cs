﻿using UnityEngine;
using System.Collections;

public class loading : MonoBehaviour {

	void Start(){
		Application.LoadLevel(1);
	}

}