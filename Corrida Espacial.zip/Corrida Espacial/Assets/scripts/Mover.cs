﻿using UnityEngine;
using System.Collections;

public class camYmove : MonoBehaviour {

	public Transform target;

	void Update () {
		float targetPosY = target.position.y;
		float targetPosX = target.position.x;
		transform.position = new Vector3(targetPosX,targetPosY,-10f);
	}
}