﻿using UnityEngine;
using System.Collections;

public class parallax : MonoBehaviour {

	void Start () {
	
	}

	void Update () {
		transform.position += new Vector3(-2f*Time.deltaTime,0f,0f);
	}
}
