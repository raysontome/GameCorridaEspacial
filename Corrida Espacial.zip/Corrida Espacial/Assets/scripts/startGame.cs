﻿using UnityEngine;
using System.Collections;

public class startGame : MonoBehaviour {

	void Update () {
		if (Input.anyKey){
			Application.LoadLevel(2);
		}
	}
}
