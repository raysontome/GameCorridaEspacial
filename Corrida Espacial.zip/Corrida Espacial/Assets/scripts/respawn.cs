﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class respawn : MonoBehaviour {

	[SerializeField]
	private GameObject Player;
	public GameObject fallingText;

	void Start(){
	}

	void OnTriggerEnter2D(Collider2D Player){
		if (Player.tag == "Player"){
			fallingText.GetComponent<fallCount>().falls++;
			Player.transform.position = new Vector3(-8f,9f,0);
			Player.transform.localRotation = Quaternion.identity;
		}
	}
}
