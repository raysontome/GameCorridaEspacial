﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class collectCoin : MonoBehaviour {

	public GameObject coinUpText;

	void OnTriggerEnter2D(Collider2D other){
		if (other.gameObject.tag=="Player"){
			coinUpText.GetComponent<nutsCount>().nuts++;
			Destroy(this.gameObject);
		}
	}
}
