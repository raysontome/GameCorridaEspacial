﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class credit : MonoBehaviour {

	public Transform prefab;

	void OnTriggerEnter2D(Collider2D other){
		Instantiate(prefab);
	}
}
